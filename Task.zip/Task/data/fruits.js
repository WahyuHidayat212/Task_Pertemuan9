/**
 * TODO 1:
 * - Buat array yang berisi data buah.
 * - Refactor variable ke ES6 Variable.
 */
let fruits = ["Apple", "Grape", "Mango", "Banana"];

// TODO 2: export variable fruits

module.exports = fruits;